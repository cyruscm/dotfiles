echo `setxkbmap -query | sed -n -e "s/layout:[ ]*//p"`
